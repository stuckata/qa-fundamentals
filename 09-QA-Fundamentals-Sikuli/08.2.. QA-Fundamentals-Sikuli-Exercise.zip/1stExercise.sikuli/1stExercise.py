TASK-1: Login in Softuni.bg
    1.	Run Sikuli IDE from runIDE.cmd
    2.	Use click() function from the left sidebar
    3.    After SELECT AN IMAGE is present select the browser icon "chrome-2.png"
    4.    Now open SoftUni.bg in your browser
    5.    Use wait() function from the left sidebar
    6.    After SELECT AN IMAGE is present select SoftUni logo "logo_SoftUni.png"
    7.    Add timeout to the already appeared function in Sikuli IDE in seconds wait("logo_SoftUni.png", timeout)
    8.    Use click() function
    9.    Select `Вход` button "button_Enter.png"
    10.    Use type()
    11.    Type your Username
    12.    Use type()
    13.    Type your Password
    14.    Use click()
    15.    Select `Вход` button "grsgrs.png"
    16.    Verify that you are logged in by using exists() function and add timeout like in wait() function

Task-2 click on checkbox with label `I have a powerful track` (Use RegionExercises.html file)

Task-3 click on checkboxes with label `I have a powerful car` and `I have a powerful boat` (Use RegionExercises.html file)
